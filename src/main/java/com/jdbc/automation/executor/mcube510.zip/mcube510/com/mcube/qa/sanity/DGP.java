package com.jdbc.automation.executor.mcube510.com.mcube.qa.sanity;

public class DGP {

    public static void main(String args[]) throws InterruptedException {

//        System.setProperty("webdriver.chrome.driver","");
//        ChromeOptions options = new ChromeOptions();
//        options.addArguments("--remote-alow-origin=*");
//        WebDriver driver = new ChromeDriver(options);
//
//        driver.get("https://www.google.com");
//        //WebEl capture all the languages present in the bar
//        List<WebElement> webEl = driver.findElements(By.xpath(""));
//        //English is clicked
////        webEl.get(0).click();
//        String nameOfLang = "";
//        for(WebElement we : webEl)
//        {
//            nameOfLang = we.getText();
//            System.out.println("Language : "+nameOfLang);
//            we.click();
//            Thread.sleep(5000);
//
//        }

    }
}
