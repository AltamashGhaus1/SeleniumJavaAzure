package com.jdbc.automation.executor.mcube510.com.mcube.qa.sanity;

public class test {
}
